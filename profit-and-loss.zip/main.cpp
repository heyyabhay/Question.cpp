#include <iostream>
using namespace std;
int main()
{
    int sp,cp;
    cout<<"Enter selling price : ";
    cin>>sp;
    cout<<"Enter cost price : ";
    cin>>cp;
    if (sp>cp) cout<<"profit : ";
    else cout<<"loss : ";
      int x= sp-cp;
      cout<<x;
//     int loss= cp-sp;
    
//      cout<<"\nprofit"<<profit;
//     //  if (x=(profit/cp)*100) cout<<x;
//     //  else cout<<"loss";
//      cout<<"\nloss "<<loss;
     
    
    
}